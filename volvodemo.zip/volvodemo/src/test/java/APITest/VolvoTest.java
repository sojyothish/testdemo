package APITest;



import org.testng.annotations.Test;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;

import javax.swing.text.html.HTMLDocument.Iterator;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class VolvoTest {
	
	Map< String, Object> map = new HashMap<String,Object>();
	JSONObject request = new JSONObject(map);
	
	@Test (priority = 1)
	public void test()
	{
		baseURI="https://reqres.in/api/register";
		given().header("Content-Type","application/json").
		body(request.toJSONString()).
		then().statusCode(200).
		log().all();
		
	}
	@Test (priority = 0)
	public void test2() throws Exception 
	{
		
		
		File f = new File("C:\\Users\\MY PC\\Downloads\\Testdata.xlsx");
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook excelWorkbook = new XSSFWorkbook(fis);
		XSSFSheet excelSheet = excelWorkbook.getSheetAt(0);
		int rows = excelSheet.getPhysicalNumberOfRows();
		int cols = excelSheet.getRow(1).getPhysicalNumberOfCells();
		String data[][]= new String[rows][cols];
		XSSFCell cell;
		
		for(int j=0; j<cols; j++)
		{
			request.put(excelSheet.getRow(0).getCell(j).getStringCellValue(), excelSheet.getRow(1).getCell(j).getStringCellValue());
		}
		
		
		
		 System.out.println(request.toJSONString());
	
		
		fis.close();	
	}
}
